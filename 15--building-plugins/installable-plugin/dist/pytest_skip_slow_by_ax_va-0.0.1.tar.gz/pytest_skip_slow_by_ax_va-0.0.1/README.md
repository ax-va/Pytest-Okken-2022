# pytest-skip-slow-by-ax-va
A pytest plugin to skip `@pytest.mark.slow` tests by default.
Include the slow tests with `--slow`.